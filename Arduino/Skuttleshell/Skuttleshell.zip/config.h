#ifndef CONFIG_H
#define CONFIG_H

#define WIFI_SSID "Work Evolution WIFI"
#define WIFI_PASSWORD "WorkEvolution2022"
//define WIFI_SSID  "ARRIS-5FE9"
//define WIFI_PASSWORD  "5G4233200217"

#define MODULE  "SkuttleCommandMK1"
#define ID "SC0001" //Serial Number

#endif